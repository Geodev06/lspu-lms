<?php

namespace App\Livewire\Base;

use Livewire\Component;

class Header extends Component
{
    public function render()
    {
        return view('livewire.base.header');
    }
}
