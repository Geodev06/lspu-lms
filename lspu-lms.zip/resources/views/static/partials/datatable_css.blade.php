<link rel="stylesheet" href="{{ asset('DataTables/datatable-bs.min.css') }}">
<link rel="stylesheet" href="{{ asset('DataTables/datatable-bs5.css') }}">


