<script src="{{ asset('DataTables/datatables.js') }}"></script>
<script src="{{ asset('DataTables/datatables.min.js') }}"></script>


 