 <div class="content-wrapper">
     <!-- Content -->

     <div class="container-xxl flex-grow-1 container-p-y">

         <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Account /</span> Settings </h4>

         <div class="row g-6 mb-3 ">

             <div class="col-sm-6 col-xl-12 mb-3 h-100">
                 <div class="card">
                     <div class="card-body">
                         <p>
                             &#9881;
                             Working in Progress..</p>


                     </div>
                 </div>
             </div>

         </div>



     </div>
     <!-- / Content -->

     <!-- Footer -->
     <livewire:base.footer />
     <!-- / Footer -->

 </div>